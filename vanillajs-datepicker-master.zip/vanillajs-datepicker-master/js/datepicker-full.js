import Datepicker from './Datepicker.js';
import DateRangePicker from './DateRangePicker.js';

window.Datepicker = Datepicker;
window.DateRangePicker = DateRangePicker;
