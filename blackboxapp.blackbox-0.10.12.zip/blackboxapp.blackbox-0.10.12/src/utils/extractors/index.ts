
const SnippetExtractors = [
    ,
];

export default SnippetExtractors;