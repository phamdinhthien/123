import { PDFOperator } from "../core";
export declare const svgPathToOperators: (path: string) => PDFOperator[];
//# sourceMappingURL=svgPath.d.ts.map