export declare enum ImageAlignment {
    Left = 0,
    Center = 1,
    Right = 2
}
//# sourceMappingURL=alignment.d.ts.map