export * from "./alignment";
//# sourceMappingURL=index.d.ts.map