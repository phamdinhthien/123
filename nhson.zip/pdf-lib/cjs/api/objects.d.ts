import { PDFName, PDFNumber } from "../core";
export declare const asPDFName: (name: string | PDFName) => PDFName;
export declare const asPDFNumber: (num: number | PDFNumber) => PDFNumber;
export declare const asNumber: (num: number | PDFNumber) => number;
//# sourceMappingURL=objects.d.ts.map