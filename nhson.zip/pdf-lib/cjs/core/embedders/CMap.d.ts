import { Glyph } from "../../types/fontkit";
/** `glyphs` should be an array of unique glyphs */
export declare const createCmap: (glyphs: Glyph[], glyphId: (g?: Glyph | undefined) => number) => string;
//# sourceMappingURL=CMap.d.ts.map