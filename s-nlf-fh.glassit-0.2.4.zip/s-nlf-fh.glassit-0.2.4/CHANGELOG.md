# Change Log

## [0.2.4]
- Merge pull request [#27](https://github.com/hikarin522/GlassIt-VSC/issues/27)

## [0.2.3]
- Add minimize, maximize command (#21)

## [0.2.2]
- bugfix

## [0.2.1]
- Merge pull request [#18](https://github.com/hikarin522/GlassIt-VSC/issues/18)

## [0.2.0]
- Add Linux suport (#15)

## [0.1.6]
- fix: error log output encoding
- fix: powershell option execution policy
- fix: powershell option noProfile

## [0.1.5]

## [0.1.4]
- Fix to work only on windows

## [0.1.3]
- update

## [0.1.2]
- Fixed problem not working with PowerSell 2.0

## [0.1.1]
- Optimisation

## [0.1.0]
- Changed not to use 'SetTransparency.exe'
- Delete 'glassit.path' from option

## [0.0.2]
- Bug fixes

## [0.0.1]
- Initial release
