# Contributor Covenant Code of Conduct

## Basic contribution rules

Basically I don't give a f*** about this CoC. So:
* If you have improvements - you're welcome.
* If you don't you're also welcome.
* If you wanna add some sarcasm into your messages - you're welcome, but be ready to it in answers.

## Purpose of this doc

This doc was created just to get rid of github notification about CoC.
